# flash-tests

This repo contains Playwright tests for dash.empirical.run. These tests are written and maintained by Empirical's AI agents.

[Chat with us](https://empirical.run) to have them test your app.

## Usage

```sh
npm test
```
