// This file has been moved to tests/onboarding/ directory
// All onboarding tests are now organized under the onboarding project