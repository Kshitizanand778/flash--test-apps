# Link Preview Tests

This directory contains tests for the link-preview project that simulates social media crawlers and bot user agents.

The tests in this directory use a custom user agent that mimics Facebook, Twitter, and other social media crawlers to test how the application handles link previews and metadata extraction.