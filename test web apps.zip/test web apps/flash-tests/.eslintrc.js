
/** @type {import("eslint").Linter.Config} */
module.exports = {
  extends: ["@empiricalrun/eslint-config/playwright"],
};
