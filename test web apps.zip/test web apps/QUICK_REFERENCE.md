# Quick Reference Card

## Installation
```bash
pip install -r requirements.txt
```

## Basic Usage
```bash
python src/cli.py analyze --commit <SHA> --repo <PATH>
```

## Examples
```bash
# Test addition
python src/cli.py analyze --commit 75cdcc5 --repo ./flash-tests

# Test modification  
python src/cli.py analyze --commit 5df7e4d --repo ./flash-tests

# Test removal
python src/cli.py analyze --commit 6d8159d --repo ./flash-tests

# Indirect impact (helper changes)
python src/cli.py analyze --commit 45433fd --repo ./flash-tests

# JSON output
python src/cli.py analyze --commit 45433fd --repo ./flash-tests --format json
```

## Output Types

**Added Test:**
```
📝 ADDED TESTS:
  ✓ "Test Name"
    in tests/path/file.spec.ts
```

**Removed Test:**
```
🗑️  REMOVED TESTS:
  ✗ "Test Name"
    from tests/path/file.spec.ts
```

**Modified Test:**
```
🔄 MODIFIED TESTS:
  ~ "Test Name"
    in tests/path/file.spec.ts
  ~ "Another Test" (via helper change)
    in tests/path/file.spec.ts
```

## Key Features

| Feature | Description |
|---------|-------------|
| **Direct Impact** | Tests directly added/removed/modified in commit |
| **Indirect Impact** | Tests using helper methods that were changed |
| **Format Support** | Text (pretty) or JSON (programmatic) |
| **Short SHAs** | Supports both short (75cdcc5) and full SHAs |
| **Error Handling** | Gracefully handles edge cases |

## Project Files

```
src/
  analyzer.py  ← Core analysis logic
  cli.py      ← Command-line interface

requirements.txt ← Python dependencies
pyproject.toml ← Project configuration
README.md ← Full documentation
SETUP.md ← Installation guide
APPROACH.md ← Architecture & AI transparency
EXAMPLES.sh ← Usage examples
```

## Commands

```bash
npm install          # Install dependencies
npm run build        # Compile TypeScript
npm run dev          # Run in dev mode
npm start            # Run compiled version
```

## Supported Arguments

```
--commit <sha>       Required: Git commit SHA
--repo <path>        Required: Path to repository
--format <format>    Optional: 'text' (default) or 'json'
```

## Analysis Process

1. **Git Diff** → Get changed files
2. **File Classification** → Identify test vs helper files
3. **Test Extraction** → Parse test names
4. **Dependency Analysis** → Find impacted tests
5. **Output Formatting** → Display results

## Common Issues

| Issue | Solution |
|-------|----------|
| npm not found | Install Node.js from nodejs.org |
| Repo not found | Check --repo path is correct |
| No tests found | Verify repo has .spec.ts or .test.ts files |
| Invalid commit | Check SHA is valid in that repository |

---

**Ready to use!** Follow [SETUP.md](SETUP.md) for installation.
