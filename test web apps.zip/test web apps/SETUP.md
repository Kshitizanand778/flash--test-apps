# Test Impact Analyzer - Setup & Usage Guide

## What This Tool Does

This is a **Python CLI application** that analyzes Git commits in Playwright test repositories to determine:

1. **Which tests were added** - New tests introduced in the commit
2. **Which tests were removed** - Tests deleted in the commit  
3. **Which tests were modified** - Tests changed directly in the commit
4. **Which tests were indirectly impacted** - Tests using helper methods that were changed

## Installation & Setup

### Prerequisites
- **Python 3.9+** - [Download from python.org](https://www.python.org/)
- **pip** (comes with Python)
- **Git** - Already installed on most systems

### Steps

```bash
# 1. Navigate to the project directory
cd "c:\Users\Kshit\OneDrive\Desktop\test web apps"

# 2. Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

## How to Use

Once installed, you can use the tool in one of these ways:

### Option A: Direct Python execution
```bash
python src/cli.py analyze --commit <COMMIT_SHA> --repo <REPO_PATH>
```

### Option B: Using shorthand
```bash
python src/cli.py list <REPO_PATH> <COMMIT_SHA>
```

## Examples

### Example 1: Analyze a commit in flash-tests repository
```bash
# First, clone the repository if you haven't
git clone https://github.com/empirical-run/flash-tests.git

# Then analyze a commit
python src/cli.py analyze --commit 45433fd --repo ./flash-tests
python src/cli.py analyze --commit 75cdcc5 --repo ./flash-tests
python src/cli.py analyze --commit 5df7e4d --repo ./flash-tests
```

### Example 2: Get JSON output for programmatic use
```bash
python src/cli.py analyze --commit 45433fd --repo ./flash-tests --format json
```

### Example 3: Using full commit SHA
```bash
python src/cli.py analyze --commit 45433fd1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p --repo ./flash-tests
```

## What the Output Looks Like

### Text Format (default)
```
================================================================================
✨ COMMIT: 45433fd
================================================================================

📝 ADDED TESTS:
  ✓ "safeBash tool execution to get commit SHA"
    in tests/tool-execution/session.spec.ts

🔄 MODIFIED TESTS:
  ~ "Subscribe to session and verify in Subscribed sessions list"
    in tests/sessions.spec.ts
  ~ "Filter sessions list by users"
    in tests/sessions.spec.ts
  ~ "set human triage for failed test" (via helper change)
    in tests/test-runs.spec.ts

────────────────────────────────────────────────────────────────────────────────
📊 Summary: 1 test added, 3 tests modified (1 indirectly via helper changes)
================================================================================
```

### JSON Format
```json
{
  "commitSha": "45433fd",
  "impactedTests": [
    {
      "testName": "safeBash tool execution to get commit SHA",
      "filePath": "tests/tool-execution/session.spec.ts",
      "modificationType": "added"
    },
    {
      "testName": "set human triage for failed test",
      "filePath": "tests/test-runs.spec.ts",
      "modificationType": "modified",
      "isIndirect": true
    }
  ],
  "summary": "1 test added, 1 test modified (1 indirectly via helper changes)"
}
```

## Project Structure

```
test-impact-analyzer/
├── src/
│   ├── analyzer.ts          # Core analysis logic
│   └── cli.ts              # Command-line interface
├── dist/                   # Compiled JavaScript (created after npm run build)
├── package.json           # Dependencies and scripts
├── tsconfig.json         # TypeScript configuration
├── README.md             # Full documentation
└── .gitignore           # Git ignore rules
```

## How It Works (Technical Details)

### Step 1: Parse Commit
Uses `git show --name-status` to get all files changed in the commit

### Step 2: Classify Files
- **Test files**: `*.spec.ts`, `*.test.ts` 
- **Helper files**: Files in `/helpers`, `/utils`, `/fixtures` directories
- **Other files**: Ignored for test impact analysis

### Step 3: Extract Test Names
For test files, uses regex to find test declarations:
```typescript
test('test name', () => { ... })
it('test name', () => { ... })
```

### Step 4: Analyze Dependencies
For helper files, searches all test files to find imports using patterns like:
```typescript
import { helper } from './helpers'
from './utils'
require('./helpers')
```

### Step 5: Generate Report
Groups tests by modification type and generates human-readable or JSON output

## Troubleshooting

### "Python is not recognized"
- Make sure Python is installed: https://www.python.org/
- Close and reopen PowerShell/Terminal after installation
- Verify with: `python --version`

### "No module named click" or "No module named git"
- Make sure you've run: `pip install -r requirements.txt`
- Verify you're in the correct directory
- If using virtual environment, make sure it's activated

### "Repository not found"
- Make sure the `--repo` path is correct
- Use absolute paths: `C:\Users\Kshit\path\to\repo`
- Or relative paths from current directory: `./flash-tests`

### No tests found
- Verify the repository has test files matching `*.spec.ts` or `*.test.ts`
- Check that the commit SHA is valid in that repository

### "Could not find test files"
- Make sure test files are in a `tests/` directory
- Or update the helper file search in `analyzer.py` line 220

## API for Integration

You can also import and use the analyzer in other Python code:

```python
from src.analyzer import TestImpactAnalyzer

analyzer = TestImpactAnalyzer('/path/to/repo')
result = analyzer.analyze_commit('45433fd')

print(result.impacted_tests)
print(result.summary)
```

## Commands Reference

```bash
npm install          # Install dependencies
npm run build        # Compile TypeScript to JavaScript
npm run dev          # Run in development mode with tsx (fast)
npm start            # Run compiled JavaScript

# Analyze a commit (dev mode)
npm run dev -- analyze --commit <SHA> --repo <PATH>

# Analyze a commit (compiled mode)
npm start analyze --commit <SHA> --repo <PATH>

# Get JSON output
npm run dev -- analyze --commit <SHA> --repo <PATH> --format json

# Shorthand
npm run dev -- list <REPO_PATH> <COMMIT_SHA>
```

## Next Steps

1. Install Python if you haven't already
2. Clone the flash-tests repository: `git clone https://github.com/empirical-run/flash-tests.git`
3. Run `pip install -r requirements.txt` in this project directory
4. Try analyzing a commit: `python src/cli.py analyze --commit 45433fd --repo ./flash-tests`

---

Built with ❤️ using TypeScript, Git, and Node.js
