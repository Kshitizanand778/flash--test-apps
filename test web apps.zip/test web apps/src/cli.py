#!/usr/bin/env python3
"""Test Impact Analyzer CLI - Analyze commit impacts on Playwright tests."""

import json
import sys
from pathlib import Path
import click
from analyzer import TestImpactAnalyzer


@click.group()
@click.version_option(version='1.0.0')
def cli():
    """Analyze the impact of commits on Playwright tests."""
    pass


@cli.command()
@click.option(
    '-c', '--commit',
    required=True,
    help='Commit SHA to analyze (e.g., 45433fd or full SHA)'
)
@click.option(
    '-r', '--repo',
    required=True,
    type=click.Path(exists=True),
    help='Path to the repository (e.g., /path/to/flash-tests)'
)
@click.option(
    '-f', '--format',
    type=click.Choice(['text', 'json']),
    default='text',
    help='Output format: json or text (default: text)'
)
def analyze(commit: str, repo: str, format: str):
    """Analyze a specific commit for test impacts."""
    try:
        repo_path = Path(repo).resolve()
        analyzer = TestImpactAnalyzer(str(repo_path))
        
        click.echo(f"\n📋 Analyzing commit: {commit}")
        click.echo(f"📁 Repository: {repo_path}\n")
        
        result = analyzer.analyze_commit(commit)
        
        if format == 'json':
            click.echo(json.dumps(result.to_dict(), indent=2))
        else:
            format_text_output(result)
    
    except ValueError as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Unexpected error: {str(e)}", err=True)
        sys.exit(1)


@cli.command('list')
@click.argument('repo', type=click.Path(exists=True))
@click.argument('commit')
def list_impacts(repo: str, commit: str):
    """List impacted tests for a commit (shorthand)."""
    try:
        repo_path = Path(repo).resolve()
        analyzer = TestImpactAnalyzer(str(repo_path))
        result = analyzer.analyze_commit(commit)
        format_text_output(result)
    
    except ValueError as e:
        click.echo(f"❌ Error: {str(e)}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"❌ Unexpected error: {str(e)}", err=True)
        sys.exit(1)


def format_text_output(result) -> None:
    """Format and display analysis result as text."""
    click.echo('=' * 80)
    click.echo(f"✨ COMMIT: {result.commit_sha}")
    click.echo('=' * 80)
    
    if not result.impacted_tests:
        click.echo("\n✅ No test files directly impacted by this commit.")
    else:
        # Group by modification type
        added = [t for t in result.impacted_tests if t.modification_type == 'added']
        removed = [t for t in result.impacted_tests if t.modification_type == 'removed']
        modified = [t for t in result.impacted_tests if t.modification_type == 'modified']
        
        if added:
            click.echo("\n📝 ADDED TESTS:")
            for test in added:
                click.echo(f'  ✓ "{test.test_name}"')
                click.echo(f"    in {test.file_path}")
        
        if removed:
            click.echo("\n🗑️  REMOVED TESTS:")
            for test in removed:
                click.echo(f'  ✗ "{test.test_name}"')
                click.echo(f"    from {test.file_path}")
        
        if modified:
            click.echo("\n🔄 MODIFIED TESTS:")
            for test in modified:
                indirect = " (via helper change)" if test.is_indirect else ""
                click.echo(f'  ~ "{test.test_name}"{indirect}')
                click.echo(f"    in {test.file_path}")
    
    click.echo("\n" + "-" * 80)
    click.echo(f"📊 Summary: {result.summary}")
    click.echo("=" * 80 + "\n")


if __name__ == '__main__':
    cli()
