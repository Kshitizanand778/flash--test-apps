"""Test Impact Analyzer - Core analysis engine for Playwright test repositories."""

import os
import re
from pathlib import Path
from typing import List, Dict, Tuple
from git import Repo
from git.exc import InvalidGitRepositoryError, BadName


class TestModification:
    """Represents a test that was impacted by a commit."""
    
    def __init__(self, test_name: str, file_path: str, modification_type: str, is_indirect: bool = False):
        self.test_name = test_name
        self.file_path = file_path
        self.modification_type = modification_type  # 'added', 'removed', 'modified'
        self.is_indirect = is_indirect
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            'testName': self.test_name,
            'filePath': self.file_path,
            'modificationType': self.modification_type,
            'isIndirect': self.is_indirect
        }


class CommitAnalysisResult:
    """Result of analyzing a commit."""
    
    def __init__(self, commit_sha: str, impacted_tests: List[TestModification], summary: str):
        self.commit_sha = commit_sha
        self.impacted_tests = impacted_tests
        self.summary = summary
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            'commitSha': self.commit_sha,
            'impactedTests': [test.to_dict() for test in self.impacted_tests],
            'summary': self.summary
        }


class TestImpactAnalyzer:
    """Analyzes commits to determine impact on Playwright tests."""
    
    def __init__(self, repo_path: str):
        """
        Initialize analyzer with a repository path.
        
        Args:
            repo_path: Path to the Git repository
        """
        self.repo_path = Path(repo_path).resolve()
        try:
            self.git_repo = Repo(str(self.repo_path))
        except InvalidGitRepositoryError:
            raise ValueError(f"'{repo_path}' is not a valid Git repository")
    
    def analyze_commit(self, commit_sha: str) -> CommitAnalysisResult:
        """
        Main method to analyze a commit and return impacted tests.
        
        Args:
            commit_sha: Git commit SHA (short or full)
        
        Returns:
            CommitAnalysisResult with list of impacted tests
        """
        try:
            # Get the commit
            try:
                commit = self.git_repo.commit(commit_sha)
            except BadName:
                raise ValueError(f"Invalid commit SHA: {commit_sha}")
            
            # Parse the diff to get file changes
            changed_files = self._parse_commit_diff(commit)
            
            # Analyze each changed file
            impacted_tests: List[TestModification] = []
            helpers_changed: List[str] = []
            
            for file_change in changed_files:
                if self._is_test_file(file_change['path']):
                    # Direct test file changes
                    tests = self._extract_tests_from_file(file_change['path'])
                    for test in tests:
                        impacted_tests.append(TestModification(
                            test_name=test,
                            file_path=file_change['path'],
                            modification_type=file_change['status']
                        ))
                elif self._is_helper_file(file_change['path']):
                    # Helper method changes - find all tests that use this
                    helpers_changed.append(file_change['path'])
            
            # For helper files, find which tests import them
            for helper_path in helpers_changed:
                dependent_tests = self._find_tests_importing_file(helper_path)
                for test_file in dependent_tests:
                    tests = self._extract_tests_from_file(test_file)
                    for test in tests:
                        # Check if this test is already in impacted_tests
                        already_exists = any(
                            t.test_name == test and t.file_path == test_file
                            for t in impacted_tests
                        )
                        if not already_exists:
                            impacted_tests.append(TestModification(
                                test_name=test,
                                file_path=test_file,
                                modification_type='modified',
                                is_indirect=True
                            ))
            
            # Refine modified tests with detailed diff analysis
            if any(f['status'] == 'modified' and self._is_test_file(f['path']) 
                   for f in changed_files):
                self._refine_modified_tests(commit, changed_files, impacted_tests)
            
            summary = self._generate_summary(impacted_tests)
            
            return CommitAnalysisResult(
                commit_sha=commit_sha,
                impacted_tests=impacted_tests,
                summary=summary
            )
        
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to analyze commit {commit_sha}: {str(e)}")
    
    def _parse_commit_diff(self, commit) -> List[Dict]:
        """
        Parse commit diff to extract changed files and their status.
        
        Returns:
            List of dicts with 'path' and 'status' keys
        """
        changed_files: List[Dict] = []
        
        # Get the parent commit for comparison
        if commit.parents:
            parent = commit.parents[0]
            diff_index = parent.diff(commit)
        else:
            # First commit - compare with empty tree
            diff_index = commit.tree.diff(None)
        
        for diff_item in diff_index:
            # Map status: A=added, D=deleted, M=modified, R=renamed
            status_map = {
                'A': 'added',
                'D': 'removed',
                'M': 'modified',
                'R': 'modified'  # Rename treated as modified
            }
            
            # Get the file path (use new path for renames, otherwise the path)
            file_path = diff_item.b_path if diff_item.b_path else diff_item.a_path
            status = status_map.get(diff_item.change_type, 'modified')
            
            changed_files.append({
                'path': file_path,
                'status': status,
                'change_type': diff_item.change_type
            })
        
        return changed_files
    
    def _is_test_file(self, file_path: str) -> bool:
        """Check if a file is a test file."""
        return bool(re.search(r'\.(spec|test)\.(ts|tsx|js|jsx)$', file_path))
    
    def _is_helper_file(self, file_path: str) -> bool:
        """Check if a file is a helper/utility file."""
        # Helper files are in certain directories but not test files
        if self._is_test_file(file_path):
            return False
        
        helper_patterns = [
            r'/helpers?/',
            r'/utils?/',
            r'/fixtures?/',
            r'helpers?\.(ts|tsx|js|jsx)$',
            r'utils?\.(ts|tsx|js|jsx)$',
        ]
        
        return any(re.search(pattern, file_path) for pattern in helper_patterns)
    
    def _extract_tests_from_file(self, file_path: str) -> List[str]:
        """
        Extract test names from a test file.
        
        Args:
            file_path: Relative path to file in repo
        
        Returns:
            List of test names found in the file
        """
        full_path = self.repo_path / file_path
        
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return self._extract_test_names_from_content(content)
        except (FileNotFoundError, IOError):
            # File might not exist (e.g., deleted)
            return []
    
    def _extract_test_names_from_content(self, content: str) -> List[str]:
        """
        Extract test names from file content using regex.
        
        Matches patterns like:
        - test('test name', () => {})
        - it("test name", () => {})
        - test(`test name`, async () => {})
        """
        test_names: List[str] = []
        
        # Pattern for test() and it()
        pattern = r"(?:test|it)\s*\(\s*[`'\"](.+?)[`'\"]\s*,\s*(?:async\s*)?\("
        matches = re.finditer(pattern, content)
        
        for match in matches:
            test_name = match.group(1).strip()
            if test_name:
                test_names.append(test_name)
        
        return test_names
    
    def _find_tests_importing_file(self, helper_path: str) -> List[str]:
        """
        Find all test files that import a given helper file.
        
        Args:
            helper_path: Relative path to helper file
        
        Returns:
            List of relative paths to test files importing this helper
        """
        helper_name = Path(helper_path).stem  # filename without extension
        tests_dir = self.repo_path / 'tests'
        dependent_tests: List[str] = []
        
        if not tests_dir.exists():
            return dependent_tests
        
        # Recursively search for test files
        for test_file in tests_dir.rglob('*'):
            if not test_file.is_file():
                continue
            
            if not self._is_test_file(test_file.name):
                continue
            
            try:
                with open(test_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Check if this test imports the helper
                import_patterns = [
                    f"from '{helper_path}'",
                    f'from "{helper_path}"',
                    f"from '{helper_name}'",
                    f'from "{helper_name}"',
                    f"import {helper_name}",
                    f"require('{helper_path}')",
                    f'require("{helper_path}")',
                ]
                
                if any(pattern in content for pattern in import_patterns):
                    # Get relative path from repo root
                    rel_path = test_file.relative_to(self.repo_path).as_posix()
                    dependent_tests.append(rel_path)
            except (IOError, UnicodeDecodeError):
                # Skip files that can't be read
                continue
        
        return dependent_tests
    
    def _refine_modified_tests(self, commit, changed_files: List[Dict], 
                               impacted_tests: List[TestModification]) -> None:
        """
        Refine analysis for modified test files using detailed diff.
        
        Modifies impacted_tests list in-place.
        """
        try:
            test_file_changes = [
                f for f in changed_files
                if self._is_test_file(f['path']) and f['status'] == 'modified'
            ]
            
            if not test_file_changes:
                return
            
            for file_change in test_file_changes:
                tests_in_diff = self._extract_modified_tests_from_diff(
                    commit, file_change['path']
                )
                
                # Update impacted_tests for this file
                for test in tests_in_diff:
                    existing = any(
                        t.file_path == file_change['path'] and t.test_name == test
                        for t in impacted_tests
                    )
                    
                    if not existing:
                        impacted_tests.append(TestModification(
                            test_name=test,
                            file_path=file_change['path'],
                            modification_type='modified'
                        ))
        except Exception:
            # If refinement fails, continue with basic analysis
            pass
    
    def _extract_modified_tests_from_diff(self, commit, file_path: str) -> List[str]:
        """
        Extract which specific tests were modified in the diff.
        
        Args:
            commit: Git commit object
            file_path: Path to test file
        
        Returns:
            List of test names that were modified
        """
        tests_modified: List[str] = []
        
        try:
            if commit.parents:
                parent = commit.parents[0]
                diff = parent.diff(commit)
            else:
                diff = commit.tree.diff(None)
            
            for diff_item in diff:
                item_path = diff_item.b_path if diff_item.b_path else diff_item.a_path
                
                if item_path != file_path:
                    continue
                
                # Get the diff content
                if diff_item.diff:
                    diff_content = diff_item.diff.decode('utf-8', errors='ignore')
                    
                    # Look for test declarations in diff
                    pattern = r"(?:test|it)\s*\(\s*[`'\"](.+?)[`'\"]\s*,"
                    matches = re.finditer(pattern, diff_content)
                    
                    for match in matches:
                        test_name = match.group(1).strip()
                        if test_name and test_name not in tests_modified:
                            tests_modified.append(test_name)
        except Exception:
            pass
        
        return tests_modified
    
    def _generate_summary(self, impacted_tests: List[TestModification]) -> str:
        """Generate a human-readable summary of impacts."""
        added = sum(1 for t in impacted_tests if t.modification_type == 'added')
        removed = sum(1 for t in impacted_tests if t.modification_type == 'removed')
        modified = sum(1 for t in impacted_tests if t.modification_type == 'modified')
        indirect = sum(1 for t in impacted_tests if t.is_indirect)
        
        parts: List[str] = []
        
        if added > 0:
            parts.append(f"{added} test{'s' if added > 1 else ''} added")
        
        if removed > 0:
            parts.append(f"{removed} test{'s' if removed > 1 else ''} removed")
        
        if modified > 0:
            direct_modified = modified - indirect
            parts.append(f"{modified} test{'s' if modified > 1 else ''} modified")
            if indirect > 0:
                parts.append(f"({indirect} indirectly via helper changes)")
        
        if parts:
            return ', '.join(parts)
        else:
            return 'No test files impacted by this commit'
